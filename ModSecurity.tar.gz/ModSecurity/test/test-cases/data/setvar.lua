function main()
	var = 2;
	m.setvar("TX.lua_set_var", var);
	m.setvar("IP.lua_set_var", var);
	m.setvar("GLOBAL.lua_set_var", var);
	m.setvar("RESOURCE.lua_set_var", var);
	m.setvar("SESSION.lua_set_var", var);
	m.setvar("USER.lua_set_var", var);
	return nil;
end
