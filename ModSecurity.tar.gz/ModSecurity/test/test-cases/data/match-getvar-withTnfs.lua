function main()
    ret = nil

    var = m.getvar("tx.test", "lowercase");

    return ret
end
